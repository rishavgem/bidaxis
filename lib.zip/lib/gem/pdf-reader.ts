import axios from "axios";

export async function readPdfBuffer(
  url: string
): Promise<Buffer> {

  const response =
    await axios.get(url, {

      responseType: "arraybuffer",

      headers: {

        "User-Agent":
          "Mozilla/5.0",

        Accept:
          "application/pdf",

      },

      maxRedirects: 5,

    });

  return Buffer.from(response.data);

}