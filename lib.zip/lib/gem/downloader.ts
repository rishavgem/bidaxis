import fs from "fs";
import path from "path";

import { getGemPage } from "./session";

const PDF_DIR = path.join(
  process.cwd(),
  "storage",
  "gem-pdfs"
);

export async function downloadPdf(
  url: string,
  tenderId: string
): Promise<string> {

  if (!fs.existsSync(PDF_DIR)) {
    fs.mkdirSync(PDF_DIR, {
      recursive: true,
    });
  }

  const pdfPath = path.join(
    PDF_DIR,
    `${tenderId}.pdf`
  );

  if (fs.existsSync(pdfPath)) {
    console.log("✓ PDF already exists");
    return pdfPath;
  }

  const page = getGemPage();

  if (!page) {
    throw new Error("No active GeM session.");
  }

  console.log("Downloading PDF...");

  const context = page.context();

  const response = await context.request.get(url);

  if (!response.ok()) {
    throw new Error(
      `Download failed (${response.status()})`
    );
  }

  const buffer = Buffer.from(
    await response.body()
  );

  fs.writeFileSync(pdfPath, buffer);

  console.log(`✓ Saved ${pdfPath}`);

  return pdfPath;
}