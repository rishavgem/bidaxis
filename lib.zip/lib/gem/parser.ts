function asString(value: any): string | null {
  if (value === undefined || value === null) {
    return null;
  }

  if (Array.isArray(value)) {
    if (value.length === 0) return null;
    return value.join(", ");
  }

  return String(value);
}

export function parseGemTenders(docs: any[]) {
  return docs.map((doc: any) => ({
    // ====================================
    // IDs
    // ====================================

    gemId:
      doc.b_id?.[0] ??
      (doc.id ? Number(doc.id) : null),

    tenderId:
      doc.b_bid_number?.[0] ?? "",

    tenderNumber:
      doc.b_bid_number?.[0] ?? null,

    // ====================================
    // Basic
    // ====================================

    title:
      doc.b_category_name?.[0] ??
      doc.bd_category_name?.[0] ??
      "",

    category:
      doc.bbt_title?.[0] ??
      null,

    quantity:
      doc.b_total_quantity?.[0] ?? null,

    // ====================================
    // Buyer
    // ====================================

    ministry: asString(
      doc.ba_official_details_minName
    ),

    department: asString(
      doc.ba_official_details_deptName
    ),

    organisation: asString(
      doc.ba_official_details_orgName
    ),

    buyerName: asString(
      doc["b.b_created_by"]
    ),

    // ====================================
    // Dates
    // ====================================

    publishDate: doc.final_start_date_sort?.[0]
      ? new Date(doc.final_start_date_sort[0])
      : null,

    closingDate: doc.final_end_date_sort?.[0]
      ? new Date(doc.final_end_date_sort[0])
      : null,

    openingDate: null,

    // ====================================
    // Location
    // ====================================

    location: null,
    city: null,
    state: null,
    country: "India",

    // ====================================
    // Money
    // ====================================

    emdAmount: null,

    // ====================================
    // URLs
    // ====================================

    sourceUrl:
      doc.id
        ? `https://bidplus.gem.gov.in/showbidDocument/${doc.id}`
        : null,

    documentUrl: null,

    // ====================================
    // Status
    // ====================================

    status:
      doc.b_status?.[0] === 1
        ? "ACTIVE"
        : "CLOSED",

    // ====================================
    // Flags
    // ====================================

    isCustom:
      doc.b_is_custom_item?.[0] === 1,

    isBOQ:
      doc.bd_details_is_boq === true,

    // ====================================
    // Raw GeM JSON
    // ====================================

    raw: doc,
  }));
}