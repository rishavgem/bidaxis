import { PrismaClient } from "@prisma/client";

import { fetchTenderPage } from "./details";
import { readPdfBuffer } from "./pdf-reader";
import { parsePdf } from "./pdf-parser";

const prisma = new PrismaClient();

export async function enrichTender(
  tenderId: string
) {
  const tender = await prisma.tender.findUnique({
    where: {
      tenderId,
    },
  });

  if (!tender) {
    throw new Error("Tender not found");
  }

  // Already enriched
  if (tender.pdfScanned) {
    return tender;
  }

  console.log(
    `========== ${tender.tenderId} ==========`
  );

  // ----------------------------------
  // Fetch tender detail page
  // ----------------------------------

  const details = await fetchTenderPage(
    tender.gemId!
  );

  if (!details.documentUrl) {
    console.log("No PDF found.");

    await prisma.tender.update({
      where: {
        tenderId,
      },
      data: {
        pdfScanned: true,
      },
    });

    return;
  }

  console.log(
    "Reading PDF..."
  );

  // ----------------------------------
  // Read PDF into memory
  // ----------------------------------

  const pdfBuffer = await readPdfBuffer(
    details.documentUrl
  );

  console.log(
    "Parsing PDF..."
  );

  const parsed = await parsePdf(
    pdfBuffer
  );

  console.log(
    "Saving..."
  );

  await prisma.tender.update({
    where: {
      tenderId,
    },
    data: {
      documentUrl: details.documentUrl,

      pdfDownloaded: true,
      pdfScanned: true,

      bidDocumentText:
        parsed.bidDocumentText,

      eligibility:
        parsed.eligibility,

      scopeOfWork:
        parsed.scopeOfWork,

      technicalSpecs:
        parsed.technicalSpecs,

      deliveryPeriod:
        parsed.deliveryPeriod,

      bidValidity:
        parsed.bidValidity,

      buyerEmail:
        parsed.buyerEmail,

      office:
        parsed.office,

      tenderFee:
        parsed.tenderFee,
    },
  });

  console.log(
    `✓ ${tender.tenderId} enriched`
  );

  return await prisma.tender.findUnique({
    where: {
      tenderId,
    },
  });
}