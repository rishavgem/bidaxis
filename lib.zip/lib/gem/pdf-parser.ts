import pdfParse from "pdf-parse";

function extractSection(
  text: string,
  start: string,
  end?: string
): string | null {

  const startIndex = text
    .toLowerCase()
    .indexOf(start.toLowerCase());

  if (startIndex === -1) {
    return null;
  }

  const from =
    startIndex + start.length;

  if (!end) {
    return text.substring(from).trim();
  }

  const endIndex = text
    .toLowerCase()
    .indexOf(
      end.toLowerCase(),
      from
    );

  if (endIndex === -1) {
    return text.substring(from).trim();
  }

  return text
    .substring(from, endIndex)
    .trim();
}

function extractEmail(
  text: string
): string | null {

  const match =
    text.match(
      /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i
    );

  return match
    ? match[0]
    : null;
}

function extractMoney(
  text: string
): string | null {

  const match =
    text.match(
      /₹?\s?[\d,]+(?:\.\d+)?/
    );

  return match
    ? match[0]
    : null;
}

export async function parsePdf(
  pdfBuffer: Buffer
) {

  const pdf =
    await pdfParse(pdfBuffer);

  const text = pdf.text;

  return {

    bidDocumentText: text,

    eligibility:
      extractSection(
        text,
        "Eligibility Criteria",
        "Scope of Work"
      ),

    scopeOfWork:
      extractSection(
        text,
        "Scope of Work",
        "Technical Specification"
      ),

    technicalSpecs:
      extractSection(
        text,
        "Technical Specification",
        "Delivery"
      ),

    tenderFee:
      extractMoney(text),

    deliveryPeriod:
      extractSection(
        text,
        "Delivery Period",
        "Bid Validity"
      ),

    bidValidity:
      extractSection(
        text,
        "Bid Validity",
        "EMD"
      ),

    buyerEmail:
      extractEmail(text),

    office:
      extractSection(
        text,
        "Buyer Address",
        "Email"
      ),

  };

}