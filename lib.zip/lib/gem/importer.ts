import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export interface ImportResult {
  created: number;
  updated: number;
  failed: number;
  skipped: number;
}

export async function importTenders(
  tenders: any[]
): Promise<ImportResult> {
  const result: ImportResult = {
    created: 0,
    updated: 0,
    failed: 0,
    skipped: 0,
  };

  for (const tender of tenders) {
    try {
      // Skip invalid tenders
      if (!tender.tenderId) {
        result.skipped++;
        continue;
      }

      const existing = await prisma.tender.findUnique({
        where: {
          tenderId: tender.tenderId,
        },
      });

      const isNew = !existing;

      await prisma.tender.upsert({
        where: {
          tenderId: tender.tenderId,
        },

        create: {
          // ==========================
          // IDs
          // ==========================

          tenderId: tender.tenderId,
          tenderNumber: tender.tenderNumber,
          gemId: tender.gemId,

          // ==========================
          // Basic
          // ==========================

          title: tender.title,

          // ==========================
          // Buyer
          // ==========================

          ministry: tender.ministry,
          department: tender.department,
          organisation: tender.organisation,
          buyerName: tender.buyerName ?? null,

          // ==========================
          // Tender
          // ==========================

          category: tender.category,
          location: tender.location,
          city: tender.city,
          state: tender.state,
          country: tender.country ?? "India",

          quantity: tender.quantity,

          publishDate: tender.publishDate,
          openingDate: tender.openingDate,
          closingDate: tender.closingDate,

          emdAmount: tender.emdAmount,

          // ==========================
          // Source
          // ==========================

          source: "GeM",
          sourceUrl: tender.sourceUrl,
          documentUrl: tender.documentUrl,

          // ==========================
          // Status
          // ==========================

          status: tender.status ?? "ACTIVE",

          // ==========================
          // PDF
          // ==========================

          pdfDownloaded: false,
          pdfScanned: false,

          // ==========================
          // Sync
          // ==========================

          lastSyncedAt: new Date(),
        },

        update: {
          tenderNumber: tender.tenderNumber,

          title: tender.title,

          ministry: tender.ministry,
          department: tender.department,
          organisation: tender.organisation,

          buyerName:
            tender.buyerName ?? existing?.buyerName,

          category: tender.category,
          location: tender.location,
          city: tender.city,
          state: tender.state,
          country:
            tender.country ?? existing?.country,

          quantity: tender.quantity,

          publishDate: tender.publishDate,
          openingDate: tender.openingDate,
          closingDate: tender.closingDate,

          emdAmount: tender.emdAmount,

          sourceUrl: tender.sourceUrl,
          documentUrl: tender.documentUrl,

          status:
            tender.status ?? existing?.status,

          // Preserve existing gemId
          gemId:
            tender.gemId ?? existing?.gemId,

          lastSyncedAt: new Date(),
        },
      });

      if (isNew) {
        result.created++;
      } else {
        result.updated++;
      }

    } catch (error) {
      console.error(
        `❌ Failed to import tender: ${tender.tenderId}`
      );
      console.error(error);

      result.failed++;
    }
  }

  return result;
}