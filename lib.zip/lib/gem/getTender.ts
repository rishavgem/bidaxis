import { PrismaClient } from "@prisma/client";
import { enrichTender } from "./enricher";

const prisma = new PrismaClient();

export async function getTender(
  tenderId: string
) {

  let tender = await prisma.tender.findUnique({
    where: {
      tenderId,
    },
  });

  if (!tender) {
    throw new Error("Tender not found");
  }

  // Already enriched
  if (
    tender.pdfScanned &&
    tender.bidDocumentText
  ) {
    return tender;
  }

  console.log("Enriching tender...");

  await enrichTender(tenderId);

  tender = await prisma.tender.findUnique({
    where: {
      tenderId,
    },
  });

  return tender;

}