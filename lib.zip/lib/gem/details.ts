import { page } from "./session";
import { findPdf } from "./findPdf";
import * as cheerio from "cheerio";

export interface TenderDetails {
  documentUrl: string | null;
  buyerName: string | null;
  description: string | null;
  corrigendumCount: number;
}

export async function fetchTenderPage(
  gemId: number
): Promise<TenderDetails> {

  const url =
    `https://bidplus.gem.gov.in/showbidDocument/${gemId}`;

  console.log(`Opening Tender ${gemId}`);

  const response =
    await page.goto(url, {
      waitUntil: "domcontentloaded",
      timeout: 60000,
    });

  if (!response) {
    throw new Error("Unable to load tender page");
  }

  // ----------------------------------
  // PDF returned directly
  // ----------------------------------

  const contentType =
    response.headers()["content-type"] ?? "";

  if (
    contentType.includes("application/pdf")
  ) {

    console.log("Direct PDF detected");

    return {

      documentUrl: url,

      buyerName: null,

      description: null,

      corrigendumCount: 0,

    };

  }

  // ----------------------------------
  // HTML page
  // ----------------------------------

  const html =
    await page.content();

  const pdf =
    findPdf(html);

  const $ = cheerio.load(html);

  return {

    documentUrl:
      pdf.pdfUrl,

    buyerName:
      $(".buyer-name").text().trim() ||
      $(".buyerName").text().trim() ||
      null,

    description:
      $("#description").text().trim() ||
      $(".description").text().trim() ||
      null,

    corrigendumCount:
      $(".corrigendum").length,

  };

}