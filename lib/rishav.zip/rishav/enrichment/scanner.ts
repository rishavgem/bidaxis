import { prisma } from "@/lib/prisma";

import { downloadTenderPdf } from "./pdf";
import { extractPdfText } from "./text";
import * as Parser from "./parser";

export async function scanTender(
  tenderId: string
) {
  const tender = await prisma.tender.findUnique({
    where: {
      tenderId,
    },
  });

  if (!tender) {
    throw new Error("Tender not found");
  }

  if (!tender.sourceUrl) {
    throw new Error("Tender has no source URL");
  }

  console.log("====================================");
  console.log("Scanning Tender");
  console.log("====================================");
  console.log("Tender :", tender.tenderId);

  try {

    console.log("Downloading PDF...");

    const pdfBuffer = await downloadTenderPdf(
      tender.sourceUrl
    );

    console.log(
      `✓ PDF downloaded (${pdfBuffer.length} bytes)`
    );

    // ==========================================
// EXTRACT PDF TEXT
// ==========================================

if (!pdfBuffer || pdfBuffer.length === 0) {
      throw new Error("Downloaded PDF is empty");
    }

    let text = await extractPdfText(pdfBuffer);

    // PostgreSQL cannot store NULL bytes
    text = text
      .replace(/\0/g, "")
      .replace(/\u0000/g, "")
      .replace(/[^\x09\x0A\x0D\x20-\uFFFF]/g, "")
      .replace(/\r/g, "")
      .trim();

    const rows = text
      .split("\n")
      .map((x) => x.trim())
      .filter(Boolean);

    console.log("\n====================================");
    console.log("FIRST 120 LINES");
    console.log("====================================\n");

    rows
      .slice(0, 120)
      .forEach((line, index) => {
        console.log(
          `${String(index + 1).padStart(3, "0")}: ${line}`
        );
      });

    console.log("\n====================================");
    console.log("PDF Preview");
    console.log("====================================\n");

    console.log(text.substring(0, 1200));

    const metadata =
      Parser.parseTenderText(text);

    console.log("\n====================================");
    console.log("Parsed Metadata");
    console.log("====================================\n");

    console.log(metadata);

    // ==========================================
    // SEARCH RESULTS
    // ==========================================

    console.log("\n====================================");
    console.log("SEARCH RESULTS");
    console.log("====================================");

    const labels = [
      "EMD",
      "Tender Fee",
      "Bid Participation",
      "Delivery Period",
      "Contract Period",
      "Bid Offer",
      "Total Quantity",
      "Performance Security",
      "ePBG",
      "Buyer Email",
      "Ministry",
      "Department",
      "Organisation",
    ];

    for (const label of labels) {

      console.log(`\n------------ ${label} ------------`);

      let found = false;

      rows.forEach((line, index) => {

        if (
          line
            .toLowerCase()
            .includes(label.toLowerCase())
        ) {

          found = true;

          console.log(
            `${String(index + 1).padStart(3, "0")}: ${line}`
          );

          if (rows[index + 1]) {
            console.log(
              `${String(index + 2).padStart(3, "0")}: ${rows[index + 1]}`
            );
          }

          if (rows[index + 2]) {
            console.log(
              `${String(index + 3).padStart(3, "0")}: ${rows[index + 2]}`
            );
          }

          console.log("------------------------------------");
        }
      });

      if (!found) {
        console.log("Not found");
      }
    }

    // ==========================================
    // UPDATE DATABASE
    // ==========================================

    const updateData: any = {
      pdfDownloaded: true,
      pdfScanned: true,

      scannedAt: new Date(),
      lastScanAttempt: new Date(),
      lastSyncedAt: new Date(),

      parserVersion: 4,
      scanError: null,

      // Store complete extracted text
      bidDocumentText: text,
    };

    // --------------------
    // Buyer Details
    // --------------------

    if (metadata.ministry) {
      updateData.ministry = metadata.ministry;
    }

    if (metadata.department) {
      updateData.department = metadata.department;
    }

    if (metadata.organisation) {
      updateData.organisation = metadata.organisation;
    }

    if (
      metadata.office &&
      !/^\*+$/.test(metadata.office)
    ) {
      updateData.office = metadata.office;
    }

    if (metadata.buyerEmail) {
      updateData.buyerEmail = metadata.buyerEmail;
    }

    // --------------------
    // Financial
    // --------------------

    if (metadata.emdAmount) {
      updateData.emdAmount = metadata.emdAmount;
    }

    if (metadata.tenderFee) {
      updateData.tenderFee = metadata.tenderFee;
    }

    // --------------------
    // Bid
    // --------------------

    if (metadata.bidValidity) {
      updateData.bidValidity = metadata.bidValidity;
    }

    if (metadata.deliveryPeriod) {
      updateData.deliveryPeriod = metadata.deliveryPeriod;
    }

    // --------------------
    // Quantity
    // --------------------

    if (metadata.quantity) {

      const qty = Number.parseInt(
        metadata.quantity,
        10
      );

      if (!Number.isNaN(qty)) {
        updateData.quantity = qty;
      }
    }

    await prisma.tender.update({
      where: {
        tenderId,
      },
      data: updateData,
    });

    console.log("\n✓ Tender updated in database");

    return metadata;

  } catch (error) {

    await prisma.tender.update({
      where: {
        tenderId,
      },
      data: {
        lastScanAttempt: new Date(),
        scanError:
          error instanceof Error
            ? error.message
            : "Unknown error",
      },
    });

    throw error;
  }
}