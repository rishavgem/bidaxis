import { prisma } from "@/lib/prisma";
import { scanTender } from "./scanner";

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function enrichTenders() {

  const tenders = await prisma.tender.findMany({
    where: {
      OR: [
        { emdAmount: null },
        { bidDocumentText: null }
      ]
    },
    orderBy: {
      createdAt: "asc",
    },
  });

  console.log("====================================");
  console.log("Tender Enrichment Started");
  console.log("====================================");
  console.log(`Pending: ${tenders.length}`);
  console.log("");

  let success = 0;
  let failed = 0;

  for (let i = 0; i < tenders.length; i++) {

    const tender = tenders[i];

    console.log(
      `[${i + 1}/${tenders.length}] ${tender.tenderId}`
    );

    try {

      await scanTender(tender.tenderId);

      success++;

    } catch (err: any) {

      failed++;

      console.log(
        `❌ ${tender.tenderId}`
      );

      console.log(err.message);

    }

    console.log(
      `Success: ${success} | Failed: ${failed}`
    );

    console.log("------------------------------------");

    // Don't hammer GeM
    await sleep(1000);

  }

  console.log("");
  console.log("====================================");
  console.log("ENRICHMENT COMPLETED");
  console.log("====================================");

  console.log(`Success : ${success}`);
  console.log(`Failed  : ${failed}`);
}