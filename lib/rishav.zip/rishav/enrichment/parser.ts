export interface TenderMetadata {
  ministry?: string;
  department?: string;
  organisation?: string;
  office?: string;

  buyerEmail?: string;

  bidNumber?: string;
  bidDate?: string;
  bidEndDate?: string;
  bidOpeningDate?: string;

  bidValidity?: string;
  bidType?: string;
  evaluationMethod?: string;

  itemCategory?: string;
  quantity?: string;

  emdAmount?: string;

  estimatedValue?: string;

  tenderFee?: string;

  deliveryPeriod?: string;
}

function rows(text: string) {
  return text
    .replace(/\r/g, "")
    .split("\n")
    .map((x) => x.trim())
    .filter(Boolean);
}

function valueAfter(lines: string[], keyword: string) {
  const i = lines.findIndex((l) =>
    l.toLowerCase().includes(keyword.toLowerCase())
  );

  if (i === -1) return undefined;

  const current = lines[i];

  const same = current
    .replace(new RegExp(`.*${keyword}`, "i"), "")
    .trim();

  if (
    same &&
    !same.startsWith("/") &&
    same.length < 120
  ) {
    return same;
  }

  if (lines[i + 1]) {
    return lines[i + 1].trim();
  }

  return undefined;
}

export function parseTenderText(
  text: string
): TenderMetadata {

  const lines = rows(text);

  // --------------------
  // Buyer
  // --------------------

  const buyerEmail =
    text.match(
      /Buyer Email id[:\s]*([A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,})/i
    )?.[1];

  // --------------------
  // Bid Number
  // --------------------

  const bidNumber =
    text.match(
      /GEM\/\d{4}\/B\/\d+/i
    )?.[0];

  // --------------------
  // Bid Date
  // --------------------

  const bidDate =
    text.match(
      /Dated[:\s]*([0-9]{2}-[0-9]{2}-[0-9]{4})/i
    )?.[1];

  // --------------------
  // Bid End Date
  // --------------------

  const bidEndDate =
    text.match(
      /Bid End Date\/Time\s*([0-9:-]{10,}\s+[0-9:]{8})/i
    )?.[1];

  // --------------------
  // Bid Opening Date
  // --------------------

  const openingMatch = text.match(
    /Bid Opening[\s\S]{0,60}?([0-9]{2}-[0-9]{2}-[0-9]{4}\s+[0-9:]{8})/i
  );

  // --------------------
  // Bid Validity
  // --------------------

  const bidValidityMatch = text.match(
    /Bid Offer[\s\S]{0,80}?Validity\s*\(From End Date\)\s*([\d]+\s*\(Days\))/i
  );

  // --------------------
  // EMD
  // --------------------

  const emdMatch = text.match(
    /EMD Amount\s*([0-9,.]+)/i
  );

  // --------------------
  // Delivery Period
  // --------------------

  let deliveryPeriod: string | undefined;

  const deliveryPatterns = [
    /Delivery Schedule\s*[:\-]?\s*([^\n]+)/i,
    /Period of Delivery\s*[:\-]?\s*([^\n]+)/i,
    /Delivery Period\s*[:\-]?\s*([^\n]+)/i,
    /Delivery to be completed in\s*([^\n]+)/i,
  ];

  for (const pattern of deliveryPatterns) {

    const match = text.match(pattern);

    if (match?.[1]) {

      const value = match[1].trim();

      if (
        !value.toLowerCase().startsWith("of quantity") &&
        !value.toLowerCase().includes("contracted rates")
      ) {
        deliveryPeriod = value;
        break;
      }
    }
  }

  return {

    // Buyer

    ministry: valueAfter(lines, "Ministry/State Name"),

    department: valueAfter(lines, "Department Name"),

    organisation: valueAfter(lines, "Organisation Name"),

    office: valueAfter(lines, "Office Name"),

    buyerEmail,

    // Bid

    bidNumber,

    bidDate,

    bidEndDate,

    bidOpeningDate: openingMatch?.[1],

    bidValidity: bidValidityMatch?.[1],

    bidType: valueAfter(lines, "Type of Bid"),

    evaluationMethod: valueAfter(
      lines,
      "Evaluation Method"
    ),

    // Item

    itemCategory: valueAfter(
      lines,
      "Item Category"
    ),

    quantity: valueAfter(
      lines,
      "Total Quantity"
    ),

    // Financial

    emdAmount: emdMatch?.[1],

    estimatedValue: undefined,

    tenderFee: undefined,

    // Delivery

    deliveryPeriod,
  };
}