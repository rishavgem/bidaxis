import pdfParse from "pdf-parse";

export async function extractPdfText(
  pdfBuffer: Buffer
): Promise<string> {
  const pdf = await pdfParse(pdfBuffer);

  return pdf.text;
}