import { chromium } from "playwright";

export async function downloadTenderPdf(
  sourceUrl: string
): Promise<Buffer> {
  const browser = await chromium.launch({
    headless: true,
  });

  try {
    const page = await browser.newPage();

    const response = await page.request.get(sourceUrl);

    if (!response.ok()) {
      throw new Error(
        `Failed to download PDF (${response.status()})`
      );
    }

    return Buffer.from(await response.body());
  } finally {
    await browser.close();
  }
}