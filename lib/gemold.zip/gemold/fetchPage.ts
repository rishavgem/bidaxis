import { chromium, Browser, Page } from "playwright";

const GEM_URL = "https://bidplus.gem.gov.in/all-bids";

let browser: Browser;
let page: Page;

export async function initializeGem() {
  browser = await chromium.launch({
    headless: true,
  });

  page = await browser.newPage();

  await page.goto(GEM_URL, {
    waitUntil: "networkidle",
  });

  console.log("✓ GeM opened");
}

export async function fetchGemPage() {
  if (!page) {
    throw new Error("initializeGem() must be called first.");
  }

  const responsePromise = page.waitForResponse((response) =>
    response.url().includes("all-bids-data")
  );

  const nextButton = page.locator("a.page-link.next");

  // First page
  if (!(await nextButton.isVisible())) {
    throw new Error("Next button not found.");
  }

  const response = await responsePromise;
  const json = await response.json();

  return json;
}

export async function fetchNextPage() {
  const nextButton = page.locator("a.page-link.next");

  if (!(await nextButton.isVisible())) {
    return null;
  }

  const responsePromise = page.waitForResponse((response) =>
    response.url().includes("all-bids-data")
  );

  await nextButton.click();

  const response = await responsePromise;

  return await response.json();
}

export async function closeGem() {
  await browser.close();
}