export function parseTender(doc: any) {
  return {
    tenderId:
      doc.b_bid_number?.[0] ??
      String(doc.id),

    gemId:
      doc.b_id?.[0]
        ? Number(doc.b_id[0])
        : Number(doc.id),

    tenderNumber:
      doc.b_bid_number?.[0] ?? null,

    source: "GeM",

    sourceUrl: `https://bidplus.gem.gov.in/showbidDocument/${doc.id}`,

    title:
      doc.bd_category_name?.[0] ??
      doc.b_category_name?.[0] ??
      "",

    category:
      doc.b_category_name?.[0] ?? null,

    department:
      doc.ba_official_details_deptName?.[0] ??
      null,

    buyerName:
      doc.ba_official_details_minName?.[0] ??
      null,

    quantity:
      doc.b_total_quantity?.[0]
        ? Number(doc.b_total_quantity[0])
        : null,

    publishDate:
      doc.final_start_date_sort?.[0]
        ? new Date(doc.final_start_date_sort[0])
        : null,

    closingDate:
      doc.final_end_date_sort?.[0]
        ? new Date(doc.final_end_date_sort[0])
        : null,

    estimatedValue: null,

    documentUrl: null,

    location: null,

    city: null,

    state: null,

    country: "India",

    ministry: null,

    organisation: null,

    description: null,

    eligibility: null,

    scopeOfWork: null,

    technicalSpecs: null,

    bidDocumentText: null,

    emdAmount: null,

    tenderFee: null,

    openingDate: null,

    pdfDownloaded: false,

    corrigendumCount: 0,

    status: "ACTIVE",

    lastSyncedAt: new Date(),
  };
}