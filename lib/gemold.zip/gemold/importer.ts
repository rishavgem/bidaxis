import { prisma } from "../prisma";
import { scanTender } from "../lib/pdf/scanner";

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function importTenders(tenders: any[]) {
  let created = 0;
  let updated = 0;
  let failed = 0;

  for (const tender of tenders) {

    // ==========================================
    // ONLY IMPORT BID TENDERS
    // ==========================================

    if (!/^GEM\/\d{4}\/B\//.test(tender.tenderId)) {
      console.log(
        `⏭ Skipping ${tender.tenderId} (Not a Bid tender)`
      );
      continue;
    }

    let success = false;

    for (let attempt = 1; attempt <= 3 && !success; attempt++) {

      try {

        // ==========================================
        // CHECK IF TENDER EXISTS
        // ==========================================

        const exists = await prisma.tender.findUnique({
          where: {
            tenderId: tender.tenderId,
          },
          select: {
            id: true,
            pdfScanned: true,
            corrigendumCount: true,
            closingDate: true,
            openingDate: true,
            documentUrl: true,
            sourceUrl: true,
          },
        });

        // ==========================================
        // DETECT CHANGES
        // ==========================================

        let requiresRescan = false;

        if (exists) {

          requiresRescan =
            exists.corrigendumCount !== tender.corrigendumCount ||
            exists.documentUrl !== tender.documentUrl ||
            exists.sourceUrl !== tender.sourceUrl ||
            exists.closingDate?.getTime() !==
              tender.closingDate?.getTime() ||
            exists.openingDate?.getTime() !==
              tender.openingDate?.getTime();

          if (requiresRescan) {

            console.log(
              `🔄 Corrigendum detected for ${tender.tenderId}`
            );

          }
        }

        // ==========================================
        // BUILD UPDATE OBJECT
        // ==========================================

        const updateData: any = {
          ...tender,
        };

        if (requiresRescan) {
          updateData.pdfScanned = false;
          updateData.scanError = null;
        }

        // ==========================================
        // UPSERT
        // ==========================================

        await prisma.tender.upsert({

          where: {
            tenderId: tender.tenderId,
          },

          update: updateData,

          create: {
            ...tender,
            pdfDownloaded: false,
            pdfScanned: false,
            scanError: null,
          },

        });

        if (exists) {
          updated++;
        } else {
          created++;
        }

        // ==========================================
        // SCAN IF REQUIRED
        // ==========================================

        const shouldScan =
          !exists ||
          !exists.pdfScanned ||
          requiresRescan;

        if (shouldScan) {

          try {

            console.log(
              `\n📄 Scanning ${tender.tenderId}...`
            );

            await scanTender(tender.tenderId);

            console.log(
              `✅ Scan completed for ${tender.tenderId}`
            );

          } catch (scanError) {

            console.error(
              `❌ Scan failed for ${tender.tenderId}:`,
              scanError
            );

            // Don't fail import if scanner fails

          }

        }

        success = true;

      } catch (err: any) {

        console.log(
          `Retry ${attempt}/3 for ${tender.tenderId}`
        );

        if (attempt < 3) {

          await sleep(2000);

        } else {

          console.log(
            `❌ Failed: ${tender.tenderId}`
          );

          console.error(err);

          failed++;

        }

      }

    }

  }

  return {
    created,
    updated,
    failed,
    total: tenders.length,
  };
}