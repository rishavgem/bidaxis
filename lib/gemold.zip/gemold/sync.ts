import { prisma } from "../prisma";
import {
  initializeGem,
  getGemPage,
  closeGem,
} from "./client";
import { parseTender } from "./parser";
import { importTenders } from "./importer";

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export async function syncGem(startPage = 1) {
  await initializeGem();

  try {
    const firstPage = await getGemPage(startPage);

    const total =
      firstPage.response.response.numFound;

    const totalPages = Math.ceil(total / 10);

    let imported = (startPage - 1) * 10;
    let created = 0;
    let updated = 0;
    let failed = 0;

    console.log("");
    console.log("====================================");
    console.log("GeM Synchronization Started");
    console.log("====================================");
    console.log(`Total Tenders : ${total}`);
    console.log(`Total Pages   : ${totalPages}`);
    console.log(`Start Page    : ${startPage}`);
    console.log("");

    for (
      let page = startPage;
      page <= totalPages;
      page++
    ) {
      try {
        const json =
          page === startPage
            ? firstPage
            : await getGemPage(page);

        const docs =
          json.response.response.docs;

        const tenders =
          docs.map(parseTender);

        const result =
          await importTenders(tenders);

        created += result.created;
        updated += result.updated;
        failed += result.failed;

        imported += result.total;

        const percent = (
          (page / totalPages) *
          100
        ).toFixed(2);

        console.log(
          `Page ${page}/${totalPages} (${percent}%)`
        );

        console.log(
          `Imported : ${imported}/${total}`
        );

        console.log(
          `Created : ${created} | Updated : ${updated} | Failed : ${failed}`
        );

        console.log("");

        // Refresh Prisma every 100 pages
        if (page % 100 === 0) {
          console.log(
            "Refreshing Prisma connection..."
          );

          await prisma.$disconnect();
        }

        // Prevent rate limiting
        await sleep(300);

      } catch (err) {
        console.error(
          `Error importing page ${page}`
        );

        console.error(err);

        console.log(
          "Retrying in 5 seconds..."
        );

        await sleep(5000);

        page--;
      }
    }

    console.log("");
    console.log("====================================");
    console.log("SYNC COMPLETED");
    console.log("====================================");
    console.log(`Created : ${created}`);
    console.log(`Updated : ${updated}`);
    console.log(`Failed  : ${failed}`);
    console.log(`Imported: ${created + updated}`);

    return {
      created,
      updated,
      failed,
      total: created + updated,
    };

  } finally {
    await closeGem();
    await prisma.$disconnect();
  }
}