import {
  initializeGem,
  fetchGemPage,
  fetchNextPage,
  closeGem,
} from "./fetchPage";

import { parseGemResponse } from "./parser";
import { importTenders } from "./importer";

export async function importAllGemTenders() {

  let created = 0;
  let updated = 0;
  let failed = 0;

  let pageNumber = 1;

  await initializeGem();

  try {

    let json = await fetchGemPage();

    while (json) {

      console.log("\n==============================");
      console.log(`Processing Page ${pageNumber}`);
      console.log("==============================");

      const tenders = parseGemResponse(json);

      console.log(
        `Returned ${tenders.length} tenders`
      );

      tenders
        .slice(0, 10)
        .forEach((t, i) =>
          console.log(`${i + 1}. ${t.tenderId}`)
        );

      const result = await importTenders(tenders);

      created += result.created;
      updated += result.updated;
      failed += result.failed;

      console.log(
        `Created ${created} Updated ${updated} Failed ${failed}`
      );

      pageNumber++;

      json = await fetchNextPage();

    }

  } finally {

    await closeGem();

  }

  console.log("\n==============================");
  console.log("IMPORT COMPLETE");
  console.log("==============================");

  console.log("Created :", created);
  console.log("Updated :", updated);
  console.log("Failed  :", failed);

  return {
    created,
    updated,
    failed,
  };
}