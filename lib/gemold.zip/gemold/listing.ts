import { gemClient } from "./client";

export async function fetchListing() {
  const response = await gemClient.post("/all-bids-data", {});

  console.log(response.data);

  return response.data;
}