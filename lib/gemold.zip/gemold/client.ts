import { chromium } from "playwright";

let csrfToken = "";
let cookies = "";
let browser: any;
let page: any;

/**
 * Initialize GeM session
 */
export async function initializeGem() {
  browser = await chromium.launch({
    headless: true,
  });

  page = await browser.newPage();

  await page.goto("https://bidplus.gem.gov.in/all-bids", {
    waitUntil: "networkidle",
  });

  // Allow initial requests to complete
  await page.waitForTimeout(4000);

  let captured = false;

  page.on("request", (request) => {
    if (
      captured ||
      request.method() !== "POST" ||
      !request.url().includes("all-bids-data")
    ) {
      return;
    }

    const body = request.postData() || "";

    const match = body.match(/csrf_bd_gem_nk=([^&]+)/);

    if (match) {
      csrfToken = decodeURIComponent(match[1]);
      captured = true;
    }
  });

  // Reload once so the listener captures the first API request
  await page.reload({
    waitUntil: "networkidle",
  });

  await page.waitForTimeout(3000);

  if (!csrfToken) {
    throw new Error("Failed to capture CSRF token.");
  }

  const context = page.context();

  const allCookies = await context.cookies();

  cookies = allCookies
    .map((cookie) => `${cookie.name}=${cookie.value}`)
    .join("; ");

  console.log("✓ CSRF Captured");
  console.log("✓ Cookies Captured");
  console.log("✓ GeM Session Ready");
}

/**
 * Fetch one GeM page
 */
export async function getGemPage(pageNumber: number) {
  if (!csrfToken) {
    throw new Error("initializeGem() must be called first.");
  }

  const payload = {
    page: pageNumber,

    param: {
      searchBid: "",
      searchType: "fullText",
    },

    filter: {
      bidStatusType: "ongoing_bids",
      byType: "all",
      highBidValue: "",

      byEndDate: {
        from: "",
        to: "",
      },

      sort: "Bid-End-Date-Oldest",
    },
  };

  const response = await page.request.post(
    "https://bidplus.gem.gov.in/all-bids-data",
    {
      headers: {
        "Content-Type":
          "application/x-www-form-urlencoded; charset=UTF-8",

        "X-Requested-With": "XMLHttpRequest",

        Referer: "https://bidplus.gem.gov.in/all-bids",

        Cookie: cookies,
      },

      form: {
        payload: JSON.stringify(payload),
        csrf_bd_gem_nk: csrfToken,
      },
    }
  );

  if (!response.ok()) {
    throw new Error(
      `Failed to fetch page ${pageNumber}. Status ${response.status()}`
    );
  }

  const json = await response.json();

  if (!json?.response?.response?.docs) {
    throw new Error(
      `Invalid response received for page ${pageNumber}`
    );
  }

  return json;
}

/**
 * Close browser and cleanup
 */
export async function closeGem() {
  if (page) {
    await page.close();
  }

  if (browser) {
    await browser.close();
  }

  csrfToken = "";
  cookies = "";
}