import { chromium } from "playwright";

export async function getGemTenderJson() {
  const browser = await chromium.launch({
    headless: true,
  });

  const page = await browser.newPage();

  let tenderJson: any = null;

  page.on("response", async (response) => {
    if (response.url().includes("all-bids-data")) {
      try {
        tenderJson = await response.json();
      } catch (err) {
        console.error("Failed to parse JSON", err);
      }
    }
  });

  await page.goto("https://bidplus.gem.gov.in/all-bids", {
    waitUntil: "networkidle",
  });

  await page.waitForTimeout(5000);

  await browser.close();

  return tenderJson;
}