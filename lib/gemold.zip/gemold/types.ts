export interface GemApiResponse {
  status: number;
  code: number;
  message: string;
  response: {
    response: {
      numFound: number;
      start: number;
      docs: GemTenderRaw[];
    };
  };
}

export interface GemTenderRaw {
  id: string;

  b_bid_number: string[];

  b_category_name?: string[];

  b_total_quantity?: number[];

  final_start_date_sort?: string[];

  final_end_date_sort?: string[];

  ba_official_details_deptName?: string[];
}

export interface GemTender {
  gemId: number;
  tenderNumber: string;
  category: string;
  department: string;
  quantity: number;
  publishDate: Date | null;
  closingDate: Date | null;
}