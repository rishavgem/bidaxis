export async function saveSession() {
  console.log("Saving session...");
}

export async function loadSession() {
  console.log("Loading session...");
}