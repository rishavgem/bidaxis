import { BrowserContext, Download } from "playwright";
import fs from "fs/promises";
import path from "path";

export async function downloadBidPdf(
    context: BrowserContext,
    click: () => Promise<void>
) {
    const [download]: [Download] = await Promise.all([
        context.waitForEvent("download"),
        click(),
    ]);

    const filename = download.suggestedFilename();

    const folder = path.join(process.cwd(), "downloads");

    await fs.mkdir(folder, { recursive: true });

    const savePath = path.join(folder, filename);

    await download.saveAs(savePath);

    return {
        filename,
        path: savePath,
    };
}