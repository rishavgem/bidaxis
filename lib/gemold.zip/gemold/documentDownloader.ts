import axios from "axios";
import fs from "fs";
import path from "path";

export async function downloadDocument(
  url: string,
  tenderNumber: string,
  fileName: string
) {
  const folder = path.join(
    process.cwd(),
    "storage",
    "gem",
    tenderNumber.replace(/\//g, "-")
  );

  fs.mkdirSync(folder, { recursive: true });

  const filePath = path.join(folder, fileName);

  const response = await axios({
    url,
    method: "GET",
    responseType: "stream",
  });

  const writer = fs.createWriteStream(filePath);

  response.data.pipe(writer);

  return new Promise<string>((resolve, reject) => {
    writer.on("finish", () => resolve(filePath));
    writer.on("error", reject);
  });
}