import { startGemSession, stopGemSession } from "./session";
import { fetchGemPage } from "./api";
import { parseGemResponse } from "./parser";
import { importTenders } from "./importer";

export async function importAllGemTenders() {
  let page = 1;

  // TEST MODE - Only fetch first page
  let totalPages = 1;
  let totalRecords = 0;

  let created = 0;
  let updated = 0;
  let failed = 0;
  let skipped = 0;

  console.log("====================================");
  console.log("Starting GeM Import (TEST MODE)");
  console.log("====================================");

  await startGemSession();

  try {
    while (page <= totalPages) {
      console.log("");
      console.log(`Fetching Page ${page}`);

      const json = await fetchGemPage(page);

      const response = json?.response?.response;

      if (!response) {
        console.log("No response received.");
        break;
      }

      totalRecords = response.numFound;

      // Keep this fixed for testing
      totalPages = 1;

      const tenders = parseGemResponse(json);

      if (!tenders.length) {
        console.log("No tenders returned.");
        break;
      }

      console.log(`Parsed ${tenders.length} tenders`);

      const result = await importTenders(tenders);

      created += result.created;
      updated += result.updated;
      failed += result.failed;
      skipped += result.skipped;

      console.log("");
      console.log("Current Totals");
      console.log("----------------------------");
      console.log(`Created : ${created}`);
      console.log(`Updated : ${updated}`);
      console.log(`Failed  : ${failed}`);
      console.log(`Skipped : ${skipped}`);

      // STOP AFTER FIRST PAGE
      break;
    }
  } finally {
    await stopGemSession();
  }

  console.log("");
  console.log("====================================");
  console.log("IMPORT COMPLETE");
  console.log("====================================");

  console.log(`Total Records : ${totalRecords}`);
  console.log(`Created       : ${created}`);
  console.log(`Updated       : ${updated}`);
  console.log(`Failed        : ${failed}`);
  console.log(`Skipped       : ${skipped}`);

  return {
    totalRecords,
    created,
    updated,
    failed,
    skipped,
  };
}