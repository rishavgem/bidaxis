import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export interface ImportResult {
  created: number;
  updated: number;
  failed: number;
  skipped: number;
}

export async function importTenders(
  tenders: any[]
): Promise<ImportResult> {
  const result: ImportResult = {
    created: 0,
    updated: 0,
    failed: 0,
    skipped: 0,
  };

  for (const tender of tenders) {
    try {
      // ---------------------------------------
      // Check if tender already exists
      // ---------------------------------------

      const existing = await prisma.tender.findUnique({
        where: {
          tenderId: tender.tenderId,
        },
      });

      const isNew = !existing;

      await prisma.tender.upsert({
        where: {
          tenderId: tender.tenderId,
        },

        create: {
          // ==========================
          // IDs
          // ==========================

          tenderId: tender.tenderId,
          tenderNumber: tender.tenderNumber,
          gemId: tender.gemId,

          // ==========================
          // Basic
          // ==========================

          title: tender.title,

          // ==========================
          // Buyer
          // ==========================

          ministry: tender.ministry,
          department: tender.department,
          organisation: tender.organisation,

          // ==========================
          // Tender
          // ==========================

          category: tender.category,
          location: tender.location,
          quantity: tender.quantity,

          publishDate: tender.publishDate,
          openingDate: tender.openingDate,
          closingDate: tender.closingDate,

          emdAmount: tender.emdAmount,

          // ==========================
          // Source
          // ==========================

          source: "GeM",
          sourceUrl: tender.sourceUrl,
          documentUrl: tender.documentUrl,

          // ==========================
          // PDF
          // ==========================

          pdfDownloaded: false,
          pdfScanned: false,

          // ==========================
          // Sync
          // ==========================

          lastSyncedAt: new Date(),
        },

        update: {
          tenderNumber: tender.tenderNumber,

          title: tender.title,

          ministry: tender.ministry,
          department: tender.department,
          organisation: tender.organisation,

          category: tender.category,
          location: tender.location,
          quantity: tender.quantity,

          publishDate: tender.publishDate,
          openingDate: tender.openingDate,
          closingDate: tender.closingDate,

          emdAmount: tender.emdAmount,

          sourceUrl: tender.sourceUrl,
          documentUrl: tender.documentUrl,

          // don't erase an existing gemId
          gemId: tender.gemId ?? existing?.gemId,

          lastSyncedAt: new Date(),
        },
      });

      if (isNew) {
        result.created++;
      } else {
        result.updated++;
      }
    } catch (error) {
      console.error(`Failed: ${tender.tenderId}`);
      console.error(error);

      result.failed++;
    }
  }

  return result;
}