import { GEM } from "./constants";
import { buildBidPayload } from "./payload";
import { getCsrf, getGemPage } from "./session";

export async function fetchGemPage(pageNumber = 1) {
  const page = getGemPage();

  if (!page) {
    throw new Error("GeM session not initialized.");
  }

  const { csrfField, csrfToken } = getCsrf();

  const payload = buildBidPayload(pageNumber);

  const form = new URLSearchParams();

  form.append("payload", JSON.stringify(payload));
  form.append(csrfField, csrfToken);

  console.log(`Fetching Page ${pageNumber}...`);

  const response = await page.request.post(GEM.BID_API, {
    headers: {
      "Content-Type":
        "application/x-www-form-urlencoded; charset=UTF-8",

      "X-Requested-With": "XMLHttpRequest",

      Referer: GEM.BID_LIST,

      Origin: GEM.BASE_URL,
    },

    data: form.toString(),
  });

  if (!response.ok()) {
    throw new Error(
      `GeM API returned ${response.status()}`
    );
  }

  const json = await response.json();

  const docs =
    json?.response?.response?.docs ?? [];

  console.log(
    `Received ${docs.length} tenders`
  );

  return json;
}