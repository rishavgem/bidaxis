export interface TenderExtraction {
  eligibility: string | null;

  scopeOfWork: string | null;

  technicalSpecs: string | null;

  emd: string |null;

  tenderFee: string | null;

  deliveryPeriod: string | null;

  bidValidity: string | null;

  buyerEmail: string | null;

  office: string | null;

  bidDocumentText: string;
}

function normalize(text: string) {
  return text.replace(/\r/g, "");
}

function clean(value: string | null): string | null {
  if (!value) return null;

  const result = value
    .replace(/\n{3,}/g, "\n\n")
    .trim();

  return result.length ? result : null;
}

function extractSection(
  text: string,
  keywords: string[]
): string | null {

  const lines = normalize(text).split("\n");

  let start = -1;

  for (let i = 0; i < lines.length; i++) {

    const lower = lines[i].toLowerCase();

    if (
      keywords.some(k => lower.includes(k.toLowerCase()))
    ) {
      start = i;
      break;
    }
  }

  if (start === -1) {
    return null;
  }

  const collected: string[] = [];

  for (let i = start; i < lines.length; i++) {

    const line = lines[i].trim();

    if (!line) {

      if (collected.length > 10)
        break;

      collected.push("");

      continue;
    }

    // probable next heading
    if (
      i > start &&
      /^[A-Z][A-Za-z0-9 ()/-]{5,60}$/.test(line)
    ) {
      break;
    }

    collected.push(line);
  }

  return clean(collected.join("\n"));
}

function extractLine(
  text: string,
  keywords: string[]
): string | null {

  const lines = normalize(text).split("\n");

  for (const line of lines) {

    const lower = line.toLowerCase();

    if (
      keywords.some(k => lower.includes(k.toLowerCase()))
    ) {
      return clean(line);
    }

  }

  return null;
}

export function extractTenderInformation(
  text: string
): TenderExtraction {

  return {

    eligibility: extractSection(text, [
      "eligibility",
      "qualification",
      "pre qualification",
      "buyer added bid specific terms"
    ]),

    scopeOfWork: extractSection(text, [
      "scope of work",
      "scope",
      "work description",
      "deliverables"
    ]),

    technicalSpecs: extractSection(text, [
      "technical specification",
      "technical specifications",
      "technical details",
      "specification"
    ]),

    emd: extractLine(text, [
      "emd",
      "earnest money"
    ]),

    tenderFee: extractLine(text, [
      "tender fee",
      "processing fee"
    ]),

    deliveryPeriod: extractLine(text, [
      "delivery period",
      "delivery schedule"
    ]),

    bidValidity: extractLine(text, [
      "bid validity",
      "validity"
    ]),

    buyerEmail: extractLine(text, [
      "email",
      "e-mail"
    ]),

    office: extractLine(text, [
      "office"
    ]),

    bidDocumentText: text
  };
}