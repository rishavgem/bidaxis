import { getGemPage } from "./session";
import { GEM } from "./constants";

export async function fetchTenderPage(gemId: number) {
  const page = getGemPage();

  if (!page) {
    throw new Error("GeM session not initialized.");
  }

  const url = `${GEM.BASE_URL}/showbidDocument/${gemId}`;

  console.log(`Opening Tender ${gemId}`);

  await page.goto(url, {
    waitUntil: "networkidle",
  });

  // Wait for page to render
  await page.waitForTimeout(2000);

  // ----------------------------
  // Find PDF link
  // ----------------------------

  let documentUrl: string | null = null;

  const anchors = await page.locator("a").all();

  for (const a of anchors) {
    const href = await a.getAttribute("href");

    if (!href) continue;

    if (
      href.includes(".pdf") ||
      href.includes("download") ||
      href.includes("bidDocument")
    ) {
      documentUrl = href.startsWith("http")
        ? href
        : `${GEM.BASE_URL}${href}`;

      break;
    }
  }

  return {
    html: await page.content(),
    documentUrl,
  };
}