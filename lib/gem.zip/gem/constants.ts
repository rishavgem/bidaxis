export const GEM = {
  // ==========================
  // Base URLs
  // ==========================

  BASE_URL: "https://bidplus.gem.gov.in",

  BID_LIST: "https://bidplus.gem.gov.in/all-bids",

  BID_API: "https://bidplus.gem.gov.in/all-bids-data",

  TENDER_DETAILS: "https://bidplus.gem.gov.in/bidlists",

  // ==========================
  // API Defaults
  // ==========================

  PAGE_SIZE: 10,

  DEFAULT_FILTER: {
    bidStatusType: "ongoing_bids",

    byType: "all",

    highBidValue: "",

    byEndDate: {
      from: "",
      to: "",
    },

    sort: "Bid-End-Date-Oldest",
  },
};