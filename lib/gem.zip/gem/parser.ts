function asString(value: any): string | null {
  if (!value) return null;

  if (Array.isArray(value)) {
    return value.join(", ");
  }

  return String(value);
}

export function parseGemResponse(json: any) {
  const docs = json?.response?.response?.docs ?? [];

  return docs.map((doc: any) => ({
    // =========================
    // IDs
    // =========================

    gemId:
      doc.b_id?.[0] ??
      Number(doc.id),

    tenderId:
      doc.b_bid_number?.[0] ?? "",

    // =========================
    // Basic
    // =========================

    title:
      doc.b_category_name?.[0] ??
      doc.bd_category_name?.[0] ??
      "",

    quantity:
      doc.b_total_quantity?.[0] ?? null,

    // =========================
    // Buyer
    // =========================

    ministry: asString(
      doc.ba_official_details_minName
    ),

    department: asString(
      doc.ba_official_details_deptName
    ),

    organisation: asString(
      doc.ba_official_details_orgName
    ),

    // =========================
    // Dates
    // =========================

    publishDate: doc.final_start_date_sort?.[0]
      ? new Date(doc.final_start_date_sort[0])
      : null,

    closingDate: doc.final_end_date_sort?.[0]
      ? new Date(doc.final_end_date_sort[0])
      : null,

    // =========================
    // Flags
    // =========================

    isCustom:
      doc.b_is_custom_item?.[0] === 1,

    isBOQ:
      doc.bd_details_is_boq === true,

    // =========================
    // Raw GeM document
    // =========================

    raw: doc,
  }));
}