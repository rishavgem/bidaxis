import * as cheerio from "cheerio";

export interface PdfInfo {
  pdfUrl: string | null;

  fileName: string | null;
}

export function findPdf(html: string): PdfInfo {
  const $ = cheerio.load(html);

  let pdfUrl: string | null = null;

  $("a").each((_, el) => {
    const href = $(el).attr("href");

    if (!href) return;

    if (
      href.includes(".pdf") ||
      href.includes("download") ||
      href.includes("document")
    ) {
      pdfUrl = href;

      return false;
    }
  });

  return {
    pdfUrl,

    fileName: pdfUrl
      ? pdfUrl.split("/").pop() ?? "document.pdf"
      : null,
  };
}