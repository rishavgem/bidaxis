import { chromium, Browser, BrowserContext, Page } from "playwright";
import { GEM } from "./constants";

let browser: Browser;
let context: BrowserContext;
let page: Page;

let csrfField = "";
let csrfToken = "";

export async function startGemSession() {
  browser = await chromium.launch({
    headless: false,
  });

  context = await browser.newContext();

  page = await context.newPage();

  //----------------------------------------------------
  // Log EVERYTHING
  //----------------------------------------------------

  context.on("page", async (p) => {
    console.log("\n===============================");
    console.log("NEW PAGE CREATED");
    console.log("===============================");

    p.on("framenavigated", frame => {
      if (frame === p.mainFrame()) {
        console.log("\nPAGE NAVIGATED");
        console.log(frame.url());
      }
    });

    p.on("request", req => {
      console.log("REQUEST", req.method(), req.url());
    });

    p.on("response", res => {
      console.log("RESPONSE", res.status(), res.url());
    });

    p.on("download", download => {
      console.log("\n===============================");
      console.log("DOWNLOAD");
      console.log("===============================");
      console.log(download.suggestedFilename());
    });

    p.on("close", () => {
      console.log("\n===============================");
      console.log("PAGE CLOSED");
      console.log("===============================");
    });
  });

  //----------------------------------------------------
  // Original page listeners
  //----------------------------------------------------

  page.on("request", req => {
    console.log("REQUEST", req.method(), req.url());
  });

  page.on("response", res => {
    console.log("RESPONSE", res.status(), res.url());
  });

  page.on("framenavigated", frame => {
    if (frame === page.mainFrame()) {
      console.log("\n========================================");
      console.log("NAVIGATED TO");
      console.log(frame.url());
      console.log("========================================");
    }
  });

  page.on("download", download => {
    console.log("\n========================================");
    console.log("DOWNLOAD");
    console.log(download.suggestedFilename());
    console.log("========================================");
  });

  //----------------------------------------------------

  await page.goto(GEM.BID_LIST, {
    waitUntil: "networkidle",
  });

  csrfField = await page.locator("#cname").inputValue();
  csrfToken = await page.locator("#chash").inputValue();

  console.log("✓ Browser started");
  console.log("✓ CSRF Field :", csrfField);
  console.log("✓ CSRF Token :", csrfToken);
}

export function getGemPage() {
  return page;
}

export function getGemContext() {
  return context;
}

export function getCsrf() {
  return {
    csrfField,
    csrfToken,
  };
}

export async function stopGemSession() {
  await browser.close();
}