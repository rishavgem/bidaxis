import { GEM } from "./constants";

export function buildBidPayload(page: number) {
  return {
    page,

    param: {
      searchBid: "",
      searchType: "fullText",
    },

    filter: GEM.DEFAULT_FILTER,
  };
}