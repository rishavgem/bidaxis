export interface GemApiResponse {
  message: string;

  response: {
    response: {
      numFound: number;
      start: number;
      docs: GemBidDoc[];
    };
  };
}

export interface GemBidDoc {
  id: string;

  b_id: number[];

  b_bid_number: string[];

  b_category_name: string[];

  bd_category_name?: string[];

  b_total_quantity: number[];

  b_status: number[];

  b_bid_type: number[];

  b_is_bunch: number[];

  b_type: number[];

  b_bid_to_ra: number[];

  b_buyer_status: number[];

  b_eval_type: number[];

  final_start_date_sort: string[];

  final_end_date_sort: string[];

  b_is_custom_item: number[];

  is_high_value: boolean[];

  b_ra_to_bid: number[];

  b_is_inactive: number[];

  b_cat_id: string[];

  bbt_title?: string[];

  ba_official_details_minName?: string[];

  ba_official_details_deptName?: string[];

  bd_details_is_boq?: boolean[];

  bd_details_new_boq?: boolean[];
}

export interface GemTender {
  gemId: number;

  tenderId: string;

  title: string;

  description: string;

  quantity: number;

  ministry?: string;

  department?: string;

  categoryId?: string;

  isCustomItem: boolean;

  isBOQ: boolean;

  isHighValue: boolean;

  bidType: number;

  evaluationType: number;

  startDate: Date;

  endDate: Date;

  raw: GemBidDoc;
}