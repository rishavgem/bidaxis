export interface TenderExtraction {
  eligibility: string | null;

  scopeOfWork: string | null;

  technicalSpecs: string | null;

  emd: string | null;

  tenderFee: string | null;

  deliveryPeriod: string | null;

  bidValidity: string | null;

  buyerEmail: string | null;

  office: string | null;

  bidDocumentText: string;
}