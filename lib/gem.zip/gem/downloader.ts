export async function downloadPdf(
    url: string,
    tenderId: string
): Promise<string>