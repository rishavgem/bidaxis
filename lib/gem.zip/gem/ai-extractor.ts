export interface AiTenderData {
  summary: string | null;

  keywords: string[];

  estimatedValue: string | null;
}

export function generateSummary(text: string): string {
  const cleaned = text
    .replace(/\s+/g, " ")
    .trim();

  return cleaned.substring(0, 600);
}

export function extractKeywords(text: string): string[] {
  const keywords = new Set<string>();

  const dictionary = [
    "Laptop",
    "Desktop",
    "Computer",
    "Server",
    "Printer",
    "Scanner",
    "UPS",
    "Networking",
    "Switch",
    "Router",
    "OEM",
    "AMC",
    "Civil",
    "Electrical",
    "Furniture",
    "Vehicle",
    "Medical",
    "Hospital",
    "Solar",
    "CCTV",
    "Fire",
    "Software",
    "Cloud",
    "Storage"
  ];

  const lower = text.toLowerCase();

  for (const word of dictionary) {
    if (lower.includes(word.toLowerCase())) {
      keywords.add(word);
    }
  }

  return [...keywords];
}

export function extractEstimatedValue(
  text: string
): string | null {

  const patterns = [

    /₹\s?[\d,]+/i,

    /rs\.?\s?[\d,]+/i,

    /estimated value.*?([\d,]+)/i

  ];

  for (const pattern of patterns) {

    const match = text.match(pattern);

    if (match) {
      return match[0];
    }

  }

  return null;

}

export function aiExtract(
  text: string
): AiTenderData {

  return {

    summary: generateSummary(text),

    keywords: extractKeywords(text),

    estimatedValue: extractEstimatedValue(text)

  };

}