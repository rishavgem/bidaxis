import { NextResponse } from "next/server";
import { chromium } from "playwright";
import path from "path";
import fs from "fs";

export async function GET() {
  const sessionDir = path.join(process.cwd(), "gem-session");

  if (!fs.existsSync(sessionDir)) {
    fs.mkdirSync(sessionDir);
  }

  const browser = await chromium.launchPersistentContext(sessionDir, {
    headless: false,
  });

  const page = await browser.newPage();

  await page.goto("https://mkp.gem.gov.in/login");

  return NextResponse.json({
    success: true,
    message: "GeM browser launched. Login session will be saved automatically.",
  });
}