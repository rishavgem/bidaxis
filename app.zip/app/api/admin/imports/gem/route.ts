import { NextResponse } from "next/server";

import { getGemTenderJson } from "@/lib/gemold/playwrightClient";
import { parseGemResponse } from "@/lib/gemold/parser";
import { importTenders } from "@/lib/gemold/importer";

export async function GET() {
  try {
    const json = await getGemTenderJson();

    if (!json) {
      return NextResponse.json(
        {
          success: false,
          message: "Unable to fetch GeM data",
        },
        { status: 500 }
      );
    }

    const tenders = parseGemResponse(json);

    const result = await importTenders(tenders);

    return NextResponse.json({
      success: true,
      imported: result.imported,
      updated: result.updated,
      total: result.total,
    });
  } catch (error) {
    console.error("GeM Import Error:", error);

    return NextResponse.json(
      {
        success: false,
        message: "Import failed",
      },
      { status: 500 }
    );
  }
}