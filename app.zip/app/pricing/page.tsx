import Link from "next/link";

const plans = [
  {
    name: "Free",
    price: "₹0",
    description: "Perfect for beginners exploring government tenders.",
    features: [
      "View all tenders",
      "Save up to 5 tenders",
      "Basic Search",
      "Basic Dashboard",
    ],
    button: "Get Started",
    href: "/register",
    featured: false,
  },
  {
    name: "Professional",
    price: "₹999",
    description: "Ideal for businesses regularly participating in tenders.",
    features: [
      "Unlimited Saved Tenders",
      "Unlimited Tender Alerts",
      "AI Tender Recommendations",
      "Bid Documentation Support",
      "Reverse Auction Support",
      "Priority Consultancy",
    ],
    button: "Subscribe Now",
    href: "/checkout",
    featured: true,
  },
  {
    name: "Enterprise",
    price: "Custom",
    description: "Complete tender management for large organizations.",
    features: [
      "Dedicated Consultant",
      "Unlimited Users",
      "Custom Integrations",
      "Tender Management",
      "Priority Support",
      "Training Sessions",
    ],
    button: "Contact Sales",
    href: "/contact",
    featured: false,
  },
];

export default function PricingPage() {
  return (
    <main className="min-h-screen bg-slate-50">

      {/* Hero */}
      <section className="bg-gradient-to-r from-blue-950 to-blue-700 py-20 text-white">
        <div className="mx-auto max-w-6xl px-6 text-center">

          <h1 className="text-5xl font-bold">
            Simple Pricing
          </h1>

          <p className="mt-4 text-lg text-blue-100">
            Choose the plan that fits your business.
          </p>

        </div>
      </section>

      {/* Plans */}
      <section className="mx-auto max-w-7xl px-6 py-20">

        <div className="grid gap-8 md:grid-cols-3">

          {plans.map((plan) => (

            <div
              key={plan.name}
              className={`rounded-3xl p-8 shadow-lg ${
                plan.featured
                  ? "border-4 border-yellow-400 bg-white"
                  : "bg-white"
              }`}
            >
              {plan.featured && (
                <span className="rounded-full bg-yellow-400 px-4 py-2 text-sm font-bold">
                  MOST POPULAR
                </span>
              )}

              <h2 className="mt-5 text-3xl font-bold">
                {plan.name}
              </h2>

              <p className="mt-4 text-5xl font-bold text-blue-700">
                {plan.price}
              </p>

              {plan.price !== "Custom" && (
                <p className="text-slate-500">per month</p>
              )}

              <p className="mt-5 text-slate-600">
                {plan.description}
              </p>

              <ul className="mt-8 space-y-3">

                {plan.features.map((feature) => (

                  <li key={feature}>
                    ✅ {feature}
                  </li>

                ))}

              </ul>

              <Link
                href={plan.href}
                className={`mt-10 block rounded-xl py-4 text-center font-semibold ${
                  plan.featured
                    ? "bg-blue-700 text-white"
                    : "border"
                }`}
              >
                {plan.button}
              </Link>

            </div>

          ))}

        </div>

      </section>

    </main>
  );
}
