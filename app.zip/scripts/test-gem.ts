import { chromium } from "playwright";

async function main() {
  const browser = await chromium.launch({
    headless: false,
  });

  const page = await browser.newPage();

  await page.goto("https://bidplus.gem.gov.in/all-bids", {
    waitUntil: "networkidle",
  });

  console.log("\n===== Pagination HTML =====\n");

  const html = await page.locator(".pagination").innerHTML();

  console.log(html);

  console.log("\n===========================\n");

  await page.pause();
}

main();