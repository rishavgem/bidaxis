import { chromium, Page } from "playwright";

async function attachLogger(page: Page, name: string) {
  page.on("request", (req) => {
    const url = req.url().toLowerCase();

    if (
      url.includes("showbid") ||
      url.includes("download") ||
      url.includes("pdf") ||
      url.includes("document")
    ) {
      console.log("\n==============================");
      console.log(`${name} REQUEST`);
      console.log("==============================");
      console.log(req.method(), req.url());

      if (req.postData()) {
        console.log(req.postData());
      }
    }
  });

  page.on("response", (res) => {
    const url = res.url().toLowerCase();

    if (
      url.includes("showbid") ||
      url.includes("download") ||
      url.includes("pdf") ||
      url.includes("document")
    ) {
      console.log("\n==============================");
      console.log(`${name} RESPONSE`);
      console.log("==============================");
      console.log(res.status(), res.url());
    }
  });
}

async function main() {
  const browser = await chromium.launch({
    headless: false,
  });

  const context = await browser.newContext({
    acceptDownloads: true,
  });

  // Detect downloads
  context.on("download", async (download) => {
    console.log("\n==============================");
    console.log("DOWNLOAD DETECTED");
    console.log("==============================");

    console.log("Suggested filename:");
    console.log(download.suggestedFilename());

    const savePath = `downloads/${download.suggestedFilename()}`;

    await download.saveAs(savePath);

    console.log("Saved to:");
    console.log(savePath);
  });

  // Detect popup windows
  context.on("page", async (newPage) => {
    console.log("\n==============================");
    console.log("NEW PAGE CREATED");
    console.log("==============================");

    await attachLogger(newPage, "POPUP");

    await newPage.waitForLoadState().catch(() => {});

    console.log("URL:", newPage.url());

    try {
      console.log("TITLE:", await newPage.title());

      const text = await newPage.locator("body").innerText();

      console.log("\nBODY (first 1000 chars)");
      console.log(text.substring(0, 1000));

      await newPage.screenshot({
        path: "showbid.png",
        fullPage: true,
      });
    } catch (e) {
      console.log("Unable to inspect popup.");
    }
  });

  const page = await context.newPage();

  await attachLogger(page, "MAIN");

  await page.goto("https://bidplus.gem.gov.in/all-bids", {
    waitUntil: "networkidle",
  });

  await page.waitForSelector("a.bid_no_hover");

  const bid = page.locator("a.bid_no_hover").first();

  console.log("Bid Text:", await bid.innerText());
  console.log("Href:", await bid.getAttribute("href"));

  console.log("Pages Before:", context.pages().length);

  await bid.click({
    force: true,
  });

  await page.waitForTimeout(8000);

  console.log("\n==============================");
  console.log("ALL OPEN PAGES");
  console.log("==============================");

  for (const p of context.pages()) {
    console.log(await p.url());
  }

  await browser.close();
}

main().catch(console.error);