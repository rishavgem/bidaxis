import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  const tenders = await prisma.tender.findMany({
    take: 20,
    orderBy: {
      createdAt: "desc",
    },
  });

  console.table(
    tenders.map(t => ({
      tenderId: t.tenderId,
      title: t.title,
      createdAt: t.createdAt,
    }))
  );
}

main().finally(() => prisma.$disconnect());