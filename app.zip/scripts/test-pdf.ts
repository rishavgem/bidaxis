import { writeFileSync } from "fs";

import {
  startGemSession,
  stopGemSession,
} from "../lib/gem/session";

import {
  fetchTenderPage,
} from "../lib/gem/details";

async function main() {
  await startGemSession();

  const page = await fetchTenderPage(
    "GEM/2026/B/7790513"
  );

  writeFileSync(
    "debug-tender.html",
    page.html
  );

  console.log("Saved debug-tender.html");

  await stopGemSession();
}

main();