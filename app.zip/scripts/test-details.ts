import {
  startGemSession,
  stopGemSession,
} from "../lib/gem/session";

import { fetchTenderPage } from "../lib/gem/details";

async function main() {
  await startGemSession();

  const html = await fetchTenderPage(
    "GEM/2026/B/7774922"
  );

  console.log(html.substring(0, 1000));

  await stopGemSession();
}

main().catch(console.error);