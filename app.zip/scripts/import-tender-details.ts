import { Prisma } from "@prisma/client";

const model = Prisma.dmmf.datamodel.models.find(
  (m) => m.name === "Tender"
);

if (!model) {
  console.error("Tender model not found.");
  process.exit(1);
}

console.log("\n==============================");
console.log("MODEL:", model.name);
console.log("==============================\n");

for (const field of model.fields) {
  console.log({
    name: field.name,
    type: field.type,
    kind: field.kind,
    required: field.isRequired,
    list: field.isList,
    unique: field.isUnique,
    id: field.isId,
    default: field.hasDefaultValue
      ? field.default
      : undefined,
    updatedAt: field.isUpdatedAt,
  });
}

console.log("\n==============================");
console.log("TOTAL FIELDS:", model.fields.length);
console.log("==============================\n");