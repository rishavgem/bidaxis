import * as parser from "../lib/rishav/enrichment/parser";

console.log("Parser exports:");
console.log(parser);
console.log("Type:", typeof parser.parseTenderText);