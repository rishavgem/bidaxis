import "dotenv/config";
import { PrismaClient } from "@prisma/client";

console.log("DATABASE_URL exists:", !!process.env.DATABASE_URL);
console.log("DATABASE_URL host:", process.env.DATABASE_URL?.match(/@(.+)$/)?.[1]);

const prisma = new PrismaClient({
  log: ["query", "info", "warn", "error"],
});

async function main() {
  await prisma.$connect();
  console.log("Connected!");

  const count = await prisma.tender.count();
  console.log("Tender count:", count);
}

main()
  .catch(console.error)
  .finally(async () => {
    await prisma.$disconnect();
  });