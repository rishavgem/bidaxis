import { prisma } from "../lib/prisma";
import { scanTender } from "../lib/rishav/enrichment/scanner";

async function main() {
  const tender =
    await prisma.tender.findFirst();

  if (!tender) {
    console.log("No tender found");
    return;
  }

  console.log("Scanning:", tender.tenderId);

  const result =
    await scanTender(
      tender.tenderId
    );

  console.log(result);
}

main()
  .catch(console.error)
  .finally(async () => {
    await prisma.$disconnect();
  });