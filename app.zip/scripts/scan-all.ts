import { prisma } from "../lib/prisma";
import { scanTender } from "../lib/rishav/enrichment/scanner";

async function main() {
  const tenders = await prisma.tender.findMany({
    where: {
      pdfScanned: false,

      tenderId: {
        contains: "/B/",
      },

      sourceUrl: {
        not: null,
      },
    },

    select: {
      tenderId: true,
    },

    orderBy: {
      createdAt: "asc",
    },
  });

  console.log(
    `Found ${tenders.length} Bid tenders to scan.\n`
  );

  let success = 0;
  let failed = 0;
  let skipped = 0;

  for (const [index, tender] of tenders.entries()) {

    // Extra safety check
    if (!tender.tenderId.includes("/B/")) {

      skipped++;

      console.log(
        `⏭ Skipping ${tender.tenderId}`
      );

      await prisma.tender.update({
        where: {
          tenderId: tender.tenderId,
        },
        data: {
          pdfScanned: true,
          lastScanAttempt: new Date(),
          scanError: "Reverse Auction - No PDF",
        },
      });

      continue;
    }

    console.log(
      `\n[${index + 1}/${tenders.length}] ${tender.tenderId}`
    );

    try {

      await scanTender(tender.tenderId);

      success++;

    } catch (error) {

      failed++;

      console.error(
        `❌ Failed: ${tender.tenderId}`
      );

      console.error(error);
    }
  }

  console.log("\n====================================");
  console.log("SCAN COMPLETE");
  console.log("====================================");

  console.log(`Success : ${success}`);
  console.log(`Failed  : ${failed}`);
  console.log(`Skipped : ${skipped}`);
}

main()
  .catch(console.error)
  .finally(async () => {
    await prisma.$disconnect();
  });