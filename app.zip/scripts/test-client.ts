import { fetchGemTenderJSON } from "../src/gem/client";

async function main() {
  const json = await fetchGemTenderJSON();

  console.log(
    "Total Records:",
    json.response.response.numFound
  );

  console.log(
    "First Bid:",
    json.response.response.docs[0]
  );
}

main();