import {
  initializeGem,
  getGemPage,
  closeGem,
} from "../lib/gemold/client";

async function main() {
  await initializeGem();

  const page1 = await getGemPage(1);

  console.log("Page 1:", page1.response.response.start);

  // Print the complete first tender object
  console.log("\n==============================");
  console.log("FIRST TENDER OBJECT");
  console.log("==============================");
  console.log(
    JSON.stringify(
      page1.response.response.docs[0],
      null,
      2
    )
  );

  await closeGem();
}

main().catch(console.error);