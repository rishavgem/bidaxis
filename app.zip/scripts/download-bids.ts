import { chromium } from "playwright";
import { downloadBidPdf } from "../lib/gemold/downloader";

async function main() {
    const browser = await chromium.launch({
        headless: false,
    });

    const context = await browser.newContext({
        acceptDownloads: true,
    });

    const page = await context.newPage();

    await page.goto("https://bidplus.gem.gov.in/all-bids", {
        waitUntil: "networkidle",
    });

    await page.waitForSelector("a.bid_no_hover");

    const bid = page.locator("a.bid_no_hover").first();

    const bidNo = await bid.innerText();

    console.log("Downloading:", bidNo);

    const result = await downloadBidPdf(
        context,
        () => bid.click()
    );

    console.log(result);

    await browser.close();
}

main().catch(console.error);