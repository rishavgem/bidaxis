import fs from "fs/promises";
import { startGemSession, getGemContext } from "../lib/gem/session";

async function main() {
  await startGemSession();

  console.log("\n=======================================");
  console.log("Click any tender manually...");
  console.log("Waiting for a NEW TAB...");
  console.log("=======================================\n");

  const context = getGemContext();

  // Wait until GeM opens another page
  const detailPage = await context.waitForEvent("page");

  console.log("New page detected.");

  await detailPage.waitForLoadState("networkidle");

  console.log("\n=======================================");
  console.log("DETAIL PAGE URL");
  console.log("=======================================");
  console.log(detailPage.url());

  console.log("\n=======================================");
  console.log("TITLE");
  console.log("=======================================");
  console.log(await detailPage.title());

  const html = await detailPage.content();

  await fs.writeFile(
    "debug-detail-page.html",
    html
  );

  await detailPage.screenshot({
    path: "debug-detail-page.png",
    fullPage: true,
  });

  console.log("\n=======================================");
  console.log("FILES SAVED");
  console.log("=======================================");
  console.log("debug-detail-page.html");
  console.log("debug-detail-page.png");

  console.log("\nLeave the browser open for inspection...");
  await new Promise(() => {});
}

main().catch(console.error);