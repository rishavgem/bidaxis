import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  const total = await prisma.tender.count();

  const latest = await prisma.tender.findMany({
    orderBy: {
      createdAt: "desc",
    },
    take: 5,
  });

  console.log("Total Tenders:", total);

  console.log("\nLatest 5:");

  latest.forEach((t) => {
    console.log(
      `${t.tenderId} | ${t.title}`
    );
  });
}

main().finally(async () => {
  await prisma.$disconnect();
});
