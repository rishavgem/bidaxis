import { startGemSession, stopGemSession } from "../lib/gem/session";
import { fetchGemPage } from "../lib/gem/api";

async function main() {
  await startGemSession();

  const json = await fetchGemPage(1);

  console.dir(json.response.response.docs[0], {
    depth: null,
  });

  await stopGemSession();
}

main();