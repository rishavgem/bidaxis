import { enrichTenders } from "../lib/rishav/enrichment/enrich";
import { prisma } from "../lib/prisma";

async function main() {

  await enrichTenders();

}

main()
.catch(console.error)
.finally(async () => {

  await prisma.$disconnect();

});
