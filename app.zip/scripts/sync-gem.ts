import { syncGem } from "../lib/gemold/sync";

async function main() {
  const result = await syncGem();

  console.log("");
  console.log("==============================");
  console.log("GeM SYNC COMPLETE");
  console.log("==============================");
  console.log(`Created : ${result.created}`);
  console.log(`Updated : ${result.updated}`);
  console.log(`Failed  : ${result.failed}`);
  console.log(`Total   : ${result.total}`);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});