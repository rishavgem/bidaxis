import { prisma } from "../lib/prisma";

async function main() {
  const scanned = await prisma.tender.count({
    where: {
      pdfScanned: true,
    },
  });

  const remaining = await prisma.tender.count({
    where: {
      pdfScanned: false,
    },
  });

  const total = await prisma.tender.count();

  console.log({
    total,
    scanned,
    remaining,
    percent: ((scanned / total) * 100).toFixed(2) + "%",
  });
}

main().finally(() => prisma.$disconnect());